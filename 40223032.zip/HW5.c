//dorsa dorri
//40223032
#include <stdio.h>

int n, j, k, tekrari=0;
int main()
{
    printf("enter a natural number n: \n");
    scanf("%d", &n);
    char c[n+1];
    printf("enter a string with n characters: \n");
    scanf("%s", c);
    for (k=n; k>1; k--)
    {
        if ( c[k-1]==c[k-2] )
        {
            for (j=k-2; j<n; j++)
            {
                c[j]=c[j+2];
            }
            tekrari+=2;
            for (j=0; j<n-tekrari; j++)
            {
                printf("%c", c[j]);
            }
            printf("\n");
        }
    }
    return 0;
}